export const PlayerData = [
    {
        "id": 1,
        "type": "DEFUSE",
        "card_name": "Defuse"
    },
    {
        "id": 2,
        "type": "SKIP",
        "card_name": "Skip"
    },
    {
        "id": 3,
        "type": "Nope",
        "card_name": "Nope"
    },
    {
        "id": 4,
        "type": "Attack",
        "card_name": "Attack"
    }
];
