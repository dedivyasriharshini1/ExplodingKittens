const ModalBody = (props) => { 
    return ( 
        <div> 
            {props.children}
        </div>
    );
}

export default ModalBody;