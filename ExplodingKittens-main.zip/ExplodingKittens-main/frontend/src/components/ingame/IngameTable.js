

const IngameTable = (props) => {
    return  ( 
        <div></div>
    )
    ;
};

export default IngameTable;