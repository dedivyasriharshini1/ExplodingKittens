
export const player = new Object();
